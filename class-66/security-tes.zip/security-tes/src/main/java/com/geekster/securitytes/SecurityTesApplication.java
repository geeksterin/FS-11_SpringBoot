package com.geekster.securitytes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityTesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityTesApplication.class, args);
	}

}
